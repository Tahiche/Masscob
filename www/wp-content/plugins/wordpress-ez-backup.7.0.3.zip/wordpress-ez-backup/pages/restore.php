<?php
$current_user = wp_get_current_user();
$email = $current_user->user_email;
$name = $current_user->user_firstname.' '.$current_user->user_lastname;
$url = home_url('/');

if (isset($_POST['send_it'])){
$name = $_POST['name'];
$email = $_POST['email'];
$url = $_POST['url'];
$what = $_POST['what'];
$resp = ezbu_restore_it($name, $email, $url, $what);
}
?>
<div class="ezbu_restore">
<h2>EZ Backup Restoration Services</h2>
<p>Due to the risk of restoring a database and file backup this feature is not automated. There is to much risk of a user unknowingly overwriting important data by mistake when using automatic restore programs. If you wish to restore your site from a recent backup please fill out a Backup Restoration Request below. I will personally assist you in restoring your files and database for a small fee.</p>
<h2>Restoration Request</h2>
<?php if ($resp) { ?>
<p class="ezupdatedstatic"><?php echo $resp ?></p>
<?php } ?>
<form method="post">
<table>
<tr>
<td>Your Name:</td>
<td><input type="text" name="name" value="<?php echo $name ?>"></td>
</tr>
<tr>
<td>E-mail:</td>
<td><input type="text" name="email" value="<?php echo $email ?>"></td>
</tr>
<tr>
<td>Website:</td>
<td><input type="text" name="url" value="<?php echo $url ?>"></td>
</tr>
<tr>
<td>What you're restoring:</td>
<td><select name="what">
<option value="files">File Restoration</option>
<option value="db">Database Restoration</option>
</select></td>
</tr>
</table>
<input type="submit" name="send_it" value="Send Request">
</form>
</div>