<?php
        $send_file = $_POST['file'];
		$backupfolder = $_POST['buf'];
        $file = $backupfolder.'/'. $send_file;				
		$root = get_option('ezbu_root');
        $newfile = $root.'/BackupDownloads/'. $send_file;
		$newdir = $root.'/BackupDownloads';
		$ppath = get_option('ezbu_plugin');
		
if (isset($_POST['trash'])) {
		if (file_exists($file)) {
			unlink($file);
			$resp = 'Backup located at<br />'.$file.'<br />Has been removed.<br/><br/>';
		}
			$resp .= 'Checking for a copy of this backup in public downloads directory<br />';
		
		if (file_exists ($newfile)) {
			unlink($newfile);
			$resp .= 'Deleted copy of archive found in public downloads at<br />'.$newfile.'<br /><br />';
		}
			$resp .= 'No Copy of Archive found in Public Downloads at<br />'.$newfile.'</p>';	
}
	
        $path = get_option('ezbu_savewhere');
        $save_file = $newdir;
	   
$is_empty = ezbu_empty($path);
?>
<SCRIPT SRC="<?php echo $ppath; ?>functions/js/boxover.js"></SCRIPT>
<div style="width: 600px;">
<h2>Backup Browser</h2>
<p>The Backup browser is a simple tool for managing your backups. Your backups are stored in a non-public section of your webspace to prevent unauthorized users from downloading them. When you choose to download a backup it is temporarily placed into a public folder on your website for the download. Once download is complete the backup is automatically removed from the public folder.<br /><br /></p>
</div>

Saving Public Downloads to: <?php echo $save_file; ?> <br />
List of Current Backups <?php echo $path; ?>
<?php if ($is_empty == true){ ?>
<form method="post">
<input type="hidden" name="buf" value="<?php echo $path ?>">
<input type="hidden" name="download_folder" value="<?php echo $newdir ?>">
<?php
        $dhandle = opendir($path);
        $files = array();
        if ($dhandle) {

   while (false !== ($fname = readdir($dhandle))) {

      if (($fname != '.') && ($fname != '..') && ($fname != '.htaccess') &&

          ($fname != basename($_SERVER['PHP_SELF']))) {

          $files[] = (is_dir( "./$fname" )) ? "(Dir) {$fname}" : $fname;
      }
   }

   closedir($dhandle);

}
echo "<select name=\"file\">";

foreach( $files as $fname )

{
	$filesize = filesize($path.'/'.$fname);
	$filesize = format_bytes($filesize);
	
   echo '<option value="'.$fname.'">'.$fname.' - '.$filesize.'</option><br />';

}

   echo '</select>';

?>
<br /><br/>
<div style="width: 100px;" title="cssbody=[dvbdy1] cssheader=[dvhdr1] header=[Download] body=[This will place a temporary copy of your backup into a public folder and start a download of it. That public copy will be removed once the download completes.]"><input type="submit" name="download" value="Download This Backup" onclick="return confirm('This will put your backup in a temporary folder and send it to you for Download. Do you wish to continue? ')"></div>
<div style="width: 100px;" title="cssbody=[dvbdy1] cssheader=[dvhdr1] header=[Permanently Delete Backup] body=[This will delete your backup and ensure no copies are left anywhere on your server.]"><input type="submit" name="trash" value="Permanently Delete Backup" onclick="return confirm('Are you sure you want to Permanently Delete this backup? ')"></div>
</form>
<?php }else{ ?>
<p style="color: #FF0000; font-weight: bold;">No Backups Exist Yet</p><p><a href="/wp-admin/admin.php?page=ezbackup-run">Create A Backup Now</a></p>
<?php } ?>
<?php if ($resp){ ?>
<p class="ezupdatedstatic"><?php echo $resp ?></p>
<?php } ?>