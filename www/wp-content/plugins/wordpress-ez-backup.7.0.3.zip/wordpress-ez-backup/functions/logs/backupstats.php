<?php           						$configpath = dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))));		include $configpath.'/wp-load.php';				$db_username = get_option('ezbu_dbusername');		if ($_GET['key'] == $db_username){
		$scriptpath = dirname(dirname(dirname(__FILE__)));        sleep(3);
        $log = $scriptpath."/logs/log.txt";
        $end = $scriptpath."/functions/routine/marker.mk";
        $file = "$log";
        $file = escapeshellarg($file); // for the security concious (should be everyone!)

if (file_exists($end)) {
        $line = `tail -n 30 $file`;
        echo '<pre>';
        print_r($line);
        echo '</pre>';
echo "<meta http-equiv='refresh' content='0'>"; 
}else{
        $line = `tail -n 30 $file`;
        echo '<pre>';
        print_r($line);
        echo '</pre>';
}
}else{	echo 'Poking your nose where it doesnt belong eh?';}  echo '<form method="post">';  echo '<input type="submit" value="Close Window" name="submit" onClick="window.close()">';  echo '</form>';

?>