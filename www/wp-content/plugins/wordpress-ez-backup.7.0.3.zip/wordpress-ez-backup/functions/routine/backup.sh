#!/bin/bash
#
# fullsitebackup.sh V1.0
#
dbhost=
dbuser=
dbpass=
dbname=
webrootdir=
tempdir=
dirname=
tarnamebase=
email=
confdir=
attach=
. $confdir